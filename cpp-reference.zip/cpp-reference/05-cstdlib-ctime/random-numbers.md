# `<cstdlib>` et `<ctime>` — Nombres pseudo-aléatoires

## `<cstdlib>`

| Fonction | Rôle | Exemple |
|---|---|---|
| `rand()` | Produit un entier pseudo-aléatoire entre `0` et `RAND_MAX`. | `rand()` |
| `srand(seed)` | Initialise le générateur ; généralement appelé une seule fois. | `srand(time(0));` |
| `abs(n)` | Renvoie la valeur absolue d'un entier. | `abs(-7)` |

## `<ctime>`

| Fonction | Rôle | Exemple |
|---|---|---|
| `time(0)` | Renvoie le temps courant sous forme numérique, souvent utilisé comme graine. | `srand(time(0));` |

Pour obtenir un entier de 1 à 10 dans un exercice simple : `rand() % 10 + 1`. Pour des besoins plus sérieux, préférer les outils modernes de `<random>`.
