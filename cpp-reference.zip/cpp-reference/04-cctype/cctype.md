# `<cctype>` — Tester et convertir des caractères

À inclure avec `#include <cctype>`.

| Fonction | Rôle | Exemple |
|---|---|---|
| `isupper(c)` | Vérifie si `c` est une majuscule. | `isupper(c)` |
| `islower(c)` | Vérifie si `c` est une minuscule. | `islower(c)` |
| `isdigit(c)` | Vérifie si `c` est un chiffre décimal. | `isdigit(c)` |
| `isalpha(c)` | Vérifie si `c` est une lettre. | `isalpha(c)` |
| `isalnum(c)` | Vérifie si `c` est une lettre ou un chiffre. | `isalnum(c)` |
| `isspace(c)` | Vérifie si `c` est un espace blanc, comme une espace ou une tabulation. | `isspace(c)` |
| `ispunct(c)` | Vérifie si `c` est un signe de ponctuation. | `ispunct(c)` |
| `isprint(c)` | Vérifie si le caractère est imprimable, espace compris. | `isprint(c)` |
| `isgraph(c)` | Vérifie si le caractère est imprimable et n'est pas un espace. | `isgraph(c)` |
| `iscntrl(c)` | Vérifie si c'est un caractère de contrôle. | `iscntrl(c)` |
| `isxdigit(c)` | Vérifie si le caractère est hexadécimal. | `isxdigit(c)` |
| `tolower(c)` | Convertit en minuscule si possible. | `tolower(c)` |
| `toupper(c)` | Convertit en majuscule si possible. | `toupper(c)` |

Utile pour valider un mot de passe, compter les chiffres ou vérifier la présence de majuscules. Pour des caractères potentiellement négatifs, convertir en `unsigned char` avant l'appel.
