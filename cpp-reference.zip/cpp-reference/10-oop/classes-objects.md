# POO — Classes et objets

Ces mots-clés et concepts appartiennent au langage C++.

| Élément | Rôle | Exemple de forme |
|---|---|---|
| `class` | Définit un type qui regroupe données et méthodes. | `class Compte { ... };` |
| `private` | Réserve l'accès aux membres à la classe et à ses amis. | `private:` |
| `public` | Rend les membres accessibles depuis l'extérieur selon les règles C++. | `public:` |
| Constructeur | Fonction spéciale appelée à la création d'un objet. | `Compte(double solde);` |
| Méthode | Fonction membre d'une classe. | `void deposer(double montant);` |
| Objet | Instance d'une classe. | `Compte compte(100);` |
| Méthode `const` | Indique que la méthode ne modifie pas l'état observable de l'objet. | `double lireSolde() const;` |
| Encapsulation | Protège les données en contrôlant l'accès via l'interface publique. | Données privées + méthodes publiques. |

Un dépôt bancaire est une opération métier : après avoir vérifié que le montant est valide, le solde peut augmenter, par exemple `solde += montant;`. `setfill` ne fait que formater l'affichage.
