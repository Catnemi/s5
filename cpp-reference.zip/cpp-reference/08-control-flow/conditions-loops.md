# Conditions, boucles et instructions

Ces éléments font partie du langage C++ ; ce ne sont pas des fonctions d'une bibliothèque particulière.

| Instruction | Rôle | Exemple de forme |
|---|---|---|
| `if` | Exécute un bloc si une condition est vraie. | `if (age >= 18) { ... }` |
| `else` | Définit le cas contraire. | `else { ... }` |
| `else if` | Vérifie une autre condition si la précédente est fausse. | `else if (note >= 10) { ... }` |
| `switch` | Choisit un cas selon une valeur. | `switch (choix) { ... }` |
| `case` | Définit une valeur possible dans un `switch`. | `case 1:` |
| `break` | Sort du `switch` ou de la boucle la plus proche. | `break;` |
| `default` | Définit le cas par défaut dans un `switch`. | `default:` |
| `for` | Répète avec initialisation, condition et mise à jour. | `for (int i=0; i<n; i++)` |
| `while` | Répète tant que la condition est vraie. | `while (i < n)` |
| `do ... while` | Exécute au moins une fois, puis vérifie la condition. | `do { ... } while (choix != 0);` |
| `continue` | Passe à l'itération suivante. | `continue;` |
| `return` | Termine une fonction et peut renvoyer une valeur. | `return 0;` |
| `bool` | Type logique : `true` ou `false`. | `bool valide = true;` |
| Paramètre par défaut | Valeur utilisée si l'argument est omis. | `void afficher(int n = 0);` |
