# `<vector>` — Tableaux dynamiques

À inclure avec `#include <vector>`. Un `vector` stocke une série d'éléments et peut grandir ou rétrécir.

| Fonction / opération | Rôle | Exemple |
|---|---|---|
| `vector<T>` | Déclare un vecteur d'éléments de type `T`. | `vector<int> notes;` |
| `push_back(x)` | Ajoute un élément à la fin. | `notes.push_back(15);` |
| `pop_back()` | Supprime le dernier élément. | `notes.pop_back();` |
| `size()` | Renvoie le nombre d'éléments. | `notes.size()` |
| `empty()` | Vérifie si le vecteur est vide. | `notes.empty()` |
| `at(i)` | Accède à l'indice `i` avec vérification des limites. | `notes.at(0)` |
| `[i]` | Accède à l'indice `i` sans vérification des limites. | `notes[0]` |
| `front()` / `back()` | Accède au premier / dernier élément. | `notes.front()` |
| `clear()` | Supprime tous les éléments. | `notes.clear();` |

`std::vector` est souvent plus simple que gérer soi-même un tableau dynamique avec `new[]` et `delete[]`. Si l'énoncé impose la mémoire manuelle, respecte la consigne du TP.
