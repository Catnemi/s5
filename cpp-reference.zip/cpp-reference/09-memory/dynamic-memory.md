# Références et mémoire dynamique

## Références

| Élément | Rôle | Exemple |
|---|---|---|
| `T&` | Référence à une variable existante ; peut permettre de la modifier. | `void ajouter(int& solde);` |
| `const T&` | Référence en lecture seule, souvent utilisée pour éviter une copie. | `void afficher(const string& nom);` |

## Mémoire dynamique

| Instruction | Rôle | Exemple |
|---|---|---|
| `new T` | Réserve dynamiquement un objet. | `int* p = new int;` |
| `new T[n]` | Réserve un tableau dynamique de `n` éléments. | `int* notes = new int[n];` |
| `delete p` | Libère un objet réservé avec `new`. | `delete p;` |
| `delete[] p` | Libère un tableau réservé avec `new[]`. | `delete[] notes;` |
| `nullptr` | Représente un pointeur nul. | `int* p = nullptr;` |

**Règle :** `new[]` doit être associé à `delete[]`, et `new` à `delete`. Ne pas utiliser un pointeur après avoir libéré sa mémoire. Quand c'est autorisé, `vector` évite souvent cette gestion manuelle.
