# `<fstream>` — Fichiers

À inclure avec `#include <fstream>`. À réviser lorsque le cours demande de lire ou d'écrire des fichiers.

| Élément | Rôle | Exemple |
|---|---|---|
| `ifstream` | Ouvre un fichier pour lire. | `ifstream fichier("notes.txt");` |
| `ofstream` | Ouvre un fichier pour écrire. | `ofstream fichier("resultat.txt");` |
| `fstream` | Permet lecture et écriture selon le mode. | `fstream fichier;` |
| `open()` | Ouvre un fichier après création de l'objet. | `fichier.open("notes.txt");` |
| `close()` | Ferme le fichier. | `fichier.close();` |
| `is_open()` | Vérifie si le fichier est ouvert. | `fichier.is_open()` |
| `good()` | Vérifie si le flux est dans un état valide. | `fichier.good()` |
| `fail()` | Vérifie si une opération a échoué. | `fichier.fail()` |
| `eof()` | Indique si la fin du fichier a été atteinte. | `fichier.eof()` |
| `get()` | Lit un caractère. | `fichier.get(c);` |
| `getline()` | Lit une ligne. | `getline(fichier, ligne);` |
| `read()` / `write()` | Lit / écrit des blocs d'octets. | Usage avancé. |
| `put(c)` | Écrit un caractère. | `fichier.put('A');` |

Vérifier que le fichier s'est bien ouvert avant de l'utiliser. Ces fonctions ne sont pas nécessaires pour une simple opération de dépôt bancaire.
